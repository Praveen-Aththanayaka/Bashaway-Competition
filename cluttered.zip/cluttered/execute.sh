docker pull mongo:latest

if [ ! "$(docker ps -a | grep bashaway-2k23-cluttered)" ]; then
    docker run -d --name bashaway-2k23-cluttered -p 27207:27017 mongo
fi

# Data will be populated into the above database instance once the tests are run.

# Write your code here
#!/bin/bash

mongodb_host="localhost"  
mongodb_port="27017"     
mongodb_database="bashaway-2k23-cluttered"

excluded_collections=("settings")

collections=$(mongo --host $mongodb_host --port $mongodb_port --quiet --eval "db.getCollectionNames()" $mongodb_database)

for collection in $collections; do
    if [[ ! " ${excluded_collections[@]} " =~ " ${collection} " ]]; then
        echo "Dropping collection: $collection"
        mongo --host $mongodb_host --port $mongodb_port --quiet --eval "db.getCollection('$collection').drop()" $mongodb_database
    fi
done

echo "Cleanup completed. Only 'settings' collection remains."
