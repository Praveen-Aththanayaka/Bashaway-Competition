# A random count of csv files will be generated within the src directory once the tests are run.

# Write your code here
#!/bin/bash

src_dir="src"
out_dir="out"
output_file="${out_dir}/merged-scrolls.csv"

mkdir -p "$out_dir"

mkdir -p "$src_dir"

generate_gold_drakes() {
  awk -v min=1 -v max=100 'BEGIN{srand(); print int(min+rand()*(max-min+1))}'
}

for i in {1..5}; do
  filename="${src_dir}/scroll_${i}.csv"
  echo "Item,Gold Drakes" > "$filename"
  for j in {1..10}; do
    item="Item_${j}"
    gold_drakes=$(generate_gold_drakes)
    echo "${item},${gold_drakes}" >> "$filename"
  done
done

echo "CSV files created in the src directory:"
ls "$src_dir"

if [ -d "$src_dir" ] && [ "$(ls -A $src_dir)" ]; then

  cat "${src_dir}"/*.csv > "${output_file}"
  awk -F',' -v OFS=',' '{ $2 = $2 * 178; printf "%.2f,%s\n", $2, $1 }' "${output_file}" | \
    sort -t',' -k1,1nr -o "${output_file}"

  sed -i '1iSilver Sovereigns,Item' "${output_file}"

  echo "Merged and converted scrolls saved to ${output_file}"
else
  echo "No CSV files found in the src directory or the src directory does not exist."
fi




